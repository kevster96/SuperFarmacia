package com.example.superfarmacia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnComprar:
                Intent intent = new Intent(getApplicationContext(), MostrarActivity.class);
                startActivity(intent);
                break;
            case R.id.btnBuscarTienda:
                Intent intent2 = new Intent(getApplicationContext(), MapsActivity.class);
                startActivity(intent2);
                break;
            case R.id.btnAcerca:
                Intent intent3 = new Intent(getApplicationContext(), AboutUSActivity.class);
                startActivity(intent3);
                break;

            default:
                break;
        }
    }
}
