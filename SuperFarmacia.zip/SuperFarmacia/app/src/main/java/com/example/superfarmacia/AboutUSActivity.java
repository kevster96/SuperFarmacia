package com.example.superfarmacia;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class AboutUSActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_u_s);
    }
}
