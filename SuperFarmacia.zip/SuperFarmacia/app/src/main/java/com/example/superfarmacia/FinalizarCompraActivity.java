package com.example.superfarmacia;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.NetworkError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class FinalizarCompraActivity extends AppCompatActivity {
    private TextView  nombreTxt, precioTxt, totalTxt, pagarTxt;
    private EditText nombreCliente, Nit;
    private String nombre, precio;
    private int cantidad , id;
    private Spinner spinner1;
    private RequestQueue requestQueue;
    ArrayList<Integer> cantidadArray;
    public static final String IP_SERVER = "http://192.168.0.12/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalizarcompra);
        nombreTxt=findViewById(R.id.txtNombre);
        precioTxt=findViewById(R.id.txtPrecio);
        totalTxt = findViewById(R.id.txtTotal);
        spinner1= findViewById(R.id.spinner);
        pagarTxt = findViewById(R.id.txtPagar);
        nombreCliente = findViewById(R.id.NombreRecibo);
        Nit = findViewById(R.id.NitRecibo);
        llenarDatos ();
        requestQueue = Volley.newRequestQueue(this);


        ArrayAdapter<CharSequence> adapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item,cantidadArray);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setAdapter(adapter);
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                totalTxt.setText(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        totalTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                totalApagar();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    public void totalApagar(){
        double cantidadSeleccionada = Double.parseDouble(totalTxt.getText().toString());
        double precio = Double.parseDouble(precioTxt.getText().toString());
        pagarTxt.setText(String.valueOf(cantidadSeleccionada*precio));
    }

    public void llenarDatos (){
        Bundle bundle = getIntent().getExtras();
        id = (bundle.getInt("id"));
        nombre=bundle.getString("nombre");
        nombreTxt.setText(nombre);
        cantidad=(bundle.getInt("cantidad"));
        this.cantidadArray = new ArrayList<>();
        for(int aux = 1; aux <=cantidad; aux++  ){
            cantidadArray.add(aux);
        }
        precio=String.valueOf(bundle.getDouble("precio"));
        precioTxt.setText(precio);



    }


    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.btnFinalizarCompra:
                finalizarCompra();
                break;
            case R.id.btnCancelar:
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
                break;
        }

    }

    public void actualizarDato(){
            String url;
            url = IP_SERVER + "/php_sw/actualizar_cantidad.php?id_medicamento=" +this.id+
                    "&cantidad="+(cantidad-Integer.parseInt(totalTxt.getText().toString()));
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                 //   Toast.makeText(FinalizarCompraActivity.this, "Datos actualizados", Toast.LENGTH_SHORT).show();
                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            if (error instanceof TimeoutError) {
                                Toast.makeText(FinalizarCompraActivity.this, "error_network_timeout", Toast.LENGTH_SHORT).show();
                            } else if (error instanceof ServerError) {
                                Toast.makeText(FinalizarCompraActivity.this, "error_server", Toast.LENGTH_SHORT).show();
                            } else if (error instanceof NetworkError) {
                                Toast.makeText(FinalizarCompraActivity.this, "network error", Toast.LENGTH_SHORT).show();
                            } else if (error instanceof ParseError) {
                                Toast.makeText(FinalizarCompraActivity.this, "parse error", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(FinalizarCompraActivity.this, "algun otro error", Toast.LENGTH_SHORT).show();
                            }

                        }

                    });
            requestQueue.add(stringRequest);
    }

    public void finalizarCompra(){
        if(nombreCliente.getText().toString().isEmpty() || Nit.getText().toString().isEmpty()){
            Toast.makeText(FinalizarCompraActivity.this, "Falta ingresar datos.", Toast.LENGTH_SHORT).show();
        }else {
        AlertDialog.Builder alerta = new AlertDialog.Builder(FinalizarCompraActivity.this);
        alerta.setMessage("Gracias "+nombreCliente.getText().toString()+" su compra por Q"+pagarTxt.getText().toString()+" ha sido exitosa");
        alerta.setCancelable(false);
        alerta.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        AlertDialog titulo = alerta.create();
        titulo.setTitle("Confirmacion de Compra");
        titulo.show();
        actualizarDato();
    }
    }

}
